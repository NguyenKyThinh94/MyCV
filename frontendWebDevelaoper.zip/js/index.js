let moreProject1 = document.getElementById('moreProject1');
let moreProject2 = document.getElementById('moreProject2');
let moreProject3 = document.getElementById('moreProject3');


moreProject1.addEventListener('click',loadMoreProject);                     
moreProject2.addEventListener('click',loadMoreProject);                     
moreProject3.addEventListener('click',loadMoreProject);                     






function loadMoreProject(){
    let id=this.id;
    id=parseInt(id.slice(-1))-1;

    console.log(id);
    axios.get('js/project.json')
    .then(response => Reder(response.data.project[id],id))
    .catch(error => console.log(error));
    
}
function Reder(data,id){
    for(i=0;i<=2;i++){
        if(i==id){
            let query="#project"+ (i+1).toString();
            let element = document.querySelector(query);
            if(element.innerHTML==""){
                element.innerHTML=
                "<p class='pl-5'>Description:"+data.description+"</p>"+
                "<p class='pl-5'>Programming language:"+data.language+"</p>"+
                "<p class='pl-5'>Source code:"+data.githubLink+"</p>";
            } else {
                element.innerHTML="";
            }
           
        
        } else {
            let query="#project"+ (i+1).toString();
            let element = document.querySelector(query);
            element.innerHTML="";
        }
    }
   
    
}